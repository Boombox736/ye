# Socialx-Project V2.0:
# ![](banner/A1.png)
# What is Social_X:
* Social_X is a Social Engineering And Remote Access Trojan Tool.
* You can generate png/jpg/docx/xml etc. looking exe files.
* Social_X is a penetration testing tool.
# Youtube Video:
* https://www.youtube.com/watch?v=-WKf2tFiMe4

# Path
* All the files are generated in wsgi_sw/Upload_Server/images

# Picture Of Png Looking Exe File:
# ![](banner/4.png)
# Picture Of Pdf Looking Exe File:
# ![](banner/5.png)
# Pictures Of Social_X Trojan Virus:
# ![](banner/2.png)
# ![](banner/3.png)

# Reverse Shell Download-Upload Commands:
#### download FILENAME=path_of_file
#### upload path_of_file FILENAME=filename.extension

# Scan Results[don't scan in virustotal or any online scanner websites]:

### https://antiscan.me/scan/new/result?id=BF5d14fusgZ2

### https://virusscan.jotti.org/en-US/filescanjob/s7cqrjr6zf# 

# DISCLAIMER

## [!]Do not use it in illegal activities.

## [!]The user is responsable for his/her own action.

