lightblue=`tput setaf 14` 
green=`tput setaf 46`     
RED=`tput setaf 196`      
yellow=`tput setaf 11`    
purple=`tput setaf 129`   
reset=`tput sgr0` 
clear
echo ${green}
figlet Social_X -f ../banner/larry3d.flf 
echo ${green} ------------------------------------------------------------------
echo -e "                         By:Aziz Kaplan" 
echo -e "                          Version:2.0" 
echo ${green} ------------------------------------------------------------------
